// Spectrum Colorpicker
// Japanese (ja) localization
// https://github.com/seballot/spectrum

(function ( $ ) {

    var localization = $.spectrum.localization["ja"] = {
        cancelText: "中止",
        chooseText: "選択"
    };

})( jQuery );
